<header>
	<table class="full">
		<tr>
			<td valign="center">
				<form method="get" class="full"><table class=full><tr><td valign="center"><input name="search"><input type="submit" value="Поиск" style="padding-left: 20px; padding-right: 20px;"><a href="?cart=yes"><input type="button" value="кoрзина"></a></td></tr></table></form>
				
			</td>
			<td align=right>
				<b>
					<a href="?doc=about">О компании</a> |
					<a href="?doc=delivery">О доставке</a> |
					<a href="?">На главную</a>
				</b>
			</td>
		</tr>
	</table>
</header>