<table>
	<tr>
		<td valign=center>
			<img width=100 height=100 src="<?=$img?>">
		</td>
		<td valign=center>
			<?=$name?>
		</td>
		<td valign=center>
			<?=$price?> рублей
		</td>
	</tr>
</table>
<hr>